package com.lucianoneves.cadastrodeclienteseenderecos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastrodeclienteseenderecosApplicationTests {

	@Test
	void contextLoads() {
	}

}
